"use client"

import { Users, Calendar, DollarSign, TrendingUp, Droplets } from "lucide-react"

const stats = [
  {
    label: "Total Customers",
    value: "248",
    change: "+12",
    changeLabel: "this month",
    icon: Users,
  },
  {
    label: "Jobs This Week",
    value: "34",
    change: "5 remaining",
    changeLabel: "today",
    icon: Calendar,
  },
  {
    label: "Revenue (MTD)",
    value: "$18,420",
    change: "+8.2%",
    changeLabel: "vs last month",
    icon: DollarSign,
  },
  {
    label: "Completion Rate",
    value: "96.4%",
    change: "+2.1%",
    changeLabel: "vs last week",
    icon: TrendingUp,
  },
]

const recentActivity = [
  { id: 1, action: "Completed service", customer: "Michael Thompson", time: "2 hours ago" },
  { id: 2, action: "New customer added", customer: "Jennifer Brooks", time: "3 hours ago" },
  { id: 3, action: "Invoice sent", customer: "Sarah Chen", time: "4 hours ago" },
  { id: 4, action: "Service rescheduled", customer: "Robert Martinez", time: "5 hours ago" },
  { id: 5, action: "Payment received", customer: "Emily Davis", time: "6 hours ago" },
]

export function DashboardOverview() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-foreground">Dashboard</h2>
        <p className="text-sm text-muted-foreground">
          Welcome back! Here&apos;s your business overview.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <div
              key={stat.label}
              className="rounded-lg border border-border bg-card p-4"
            >
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{stat.label}</span>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </div>
              <p className="text-2xl font-semibold text-foreground">{stat.value}</p>
              <p className="mt-1 text-xs text-muted-foreground">
                <span className="text-primary">{stat.change}</span> {stat.changeLabel}
              </p>
            </div>
          )
        })}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-border bg-card">
          <div className="border-b border-border px-4 py-3">
            <h3 className="font-medium text-foreground">Recent Activity</h3>
          </div>
          <div className="divide-y divide-border">
            {recentActivity.map((activity) => (
              <div
                key={activity.id}
                className="flex items-center justify-between px-4 py-3"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                    <Droplets className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      {activity.action}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {activity.customer}
                    </p>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">
                  {activity.time}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-lg border border-border bg-card">
          <div className="border-b border-border px-4 py-3">
            <h3 className="font-medium text-foreground">Today&apos;s Schedule</h3>
          </div>
          <div className="divide-y divide-border">
            {[
              { time: "8:30 AM", customer: "James Wilson", service: "Full Clean", status: "completed" },
              { time: "11:00 AM", customer: "Michael Thompson", service: "Chemical Balance", status: "in-progress" },
              { time: "2:00 PM", customer: "Sarah Chen", service: "Vacuum & Skim", status: "upcoming" },
            ].map((job, index) => (
              <div
                key={index}
                className="flex items-center justify-between px-4 py-3"
              >
                <div className="flex items-center gap-3">
                  <span className="text-sm font-medium text-muted-foreground w-16">
                    {job.time}
                  </span>
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      {job.customer}
                    </p>
                    <p className="text-xs text-muted-foreground">{job.service}</p>
                  </div>
                </div>
                <span
                  className={`rounded-full px-2.5 py-1 text-xs font-medium ${
                    job.status === "completed"
                      ? "bg-primary/10 text-primary"
                      : job.status === "in-progress"
                      ? "bg-chart-4/20 text-chart-4"
                      : "bg-secondary text-secondary-foreground"
                  }`}
                >
                  {job.status === "completed"
                    ? "Completed"
                    : job.status === "in-progress"
                    ? "In Progress"
                    : "Upcoming"}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
