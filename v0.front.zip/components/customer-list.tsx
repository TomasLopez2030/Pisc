"use client"

import { useState } from "react"
import { Search, MoreHorizontal, Phone, Mail, MapPin } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const customers = [
  {
    id: 1,
    name: "Michael Thompson",
    email: "m.thompson@email.com",
    phone: "(555) 123-4567",
    address: "1842 Oak Valley Dr",
    poolType: "In-ground",
    lastService: "May 2, 2026",
    status: "active",
  },
  {
    id: 2,
    name: "Sarah Chen",
    email: "sarah.chen@email.com",
    phone: "(555) 234-5678",
    address: "567 Maple Lane",
    poolType: "Above-ground",
    lastService: "May 5, 2026",
    status: "active",
  },
  {
    id: 3,
    name: "Robert Martinez",
    email: "r.martinez@email.com",
    phone: "(555) 345-6789",
    address: "2901 Pine Street",
    poolType: "In-ground",
    lastService: "April 28, 2026",
    status: "pending",
  },
  {
    id: 4,
    name: "Emily Davis",
    email: "emily.d@email.com",
    phone: "(555) 456-7890",
    address: "445 Birch Avenue",
    poolType: "In-ground",
    lastService: "May 1, 2026",
    status: "active",
  },
  {
    id: 5,
    name: "James Wilson",
    email: "j.wilson@email.com",
    phone: "(555) 567-8901",
    address: "1123 Cedar Blvd",
    poolType: "Above-ground",
    lastService: "April 30, 2026",
    status: "inactive",
  },
  {
    id: 6,
    name: "Lisa Anderson",
    email: "l.anderson@email.com",
    phone: "(555) 678-9012",
    address: "789 Elm Court",
    poolType: "In-ground",
    lastService: "May 6, 2026",
    status: "active",
  },
]

export function CustomerList() {
  const [search, setSearch] = useState("")

  const filteredCustomers = customers.filter(
    (customer) =>
      customer.name.toLowerCase().includes(search.toLowerCase()) ||
      customer.email.toLowerCase().includes(search.toLowerCase()) ||
      customer.address.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Customers</h2>
          <p className="text-sm text-muted-foreground">
            Manage your pool service customers
          </p>
        </div>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
          Add Customer
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search customers by name, email, or address..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9 bg-input border-border text-foreground placeholder:text-muted-foreground"
        />
      </div>

      <div className="rounded-lg border border-border bg-card">
        <div className="grid grid-cols-[1fr,1fr,1fr,100px,80px] gap-4 border-b border-border px-4 py-3 text-sm font-medium text-muted-foreground">
          <div>Customer</div>
          <div>Contact</div>
          <div>Address</div>
          <div>Pool Type</div>
          <div></div>
        </div>
        <div className="divide-y divide-border">
          {filteredCustomers.map((customer) => (
            <div
              key={customer.id}
              className="grid grid-cols-[1fr,1fr,1fr,100px,80px] gap-4 px-4 py-3 text-sm transition-colors hover:bg-secondary/30"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary text-sm font-medium text-secondary-foreground">
                  {customer.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </div>
                <div>
                  <p className="font-medium text-foreground">{customer.name}</p>
                  <p className="text-xs text-muted-foreground">
                    Last service: {customer.lastService}
                  </p>
                </div>
              </div>
              <div className="flex flex-col justify-center gap-1">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Mail className="h-3.5 w-3.5" />
                  <span className="text-foreground">{customer.email}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Phone className="h-3.5 w-3.5" />
                  <span className="text-foreground">{customer.phone}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="h-3.5 w-3.5 shrink-0" />
                <span className="text-foreground">{customer.address}</span>
              </div>
              <div className="flex items-center">
                <span className="rounded-full bg-secondary px-2.5 py-1 text-xs font-medium text-secondary-foreground">
                  {customer.poolType}
                </span>
              </div>
              <div className="flex items-center justify-end">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-popover border-border">
                    <DropdownMenuItem className="text-foreground hover:bg-accent">View Details</DropdownMenuItem>
                    <DropdownMenuItem className="text-foreground hover:bg-accent">Edit Customer</DropdownMenuItem>
                    <DropdownMenuItem className="text-foreground hover:bg-accent">Schedule Service</DropdownMenuItem>
                    <DropdownMenuItem className="text-destructive hover:bg-accent">Remove</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          ))}
        </div>
      </div>

      <p className="text-sm text-muted-foreground">
        Showing {filteredCustomers.length} of {customers.length} customers
      </p>
    </div>
  )
}
