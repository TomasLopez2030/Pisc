"use client"

import { Clock, MapPin, User, CheckCircle2, Circle } from "lucide-react"
import { cn } from "@/lib/utils"

interface ScheduleItem {
  id: number
  customer: string
  address: string
  time: string
  service: string
  completed: boolean
}

interface DaySchedule {
  day: string
  date: string
  isToday: boolean
  items: ScheduleItem[]
}

const weekSchedule: DaySchedule[] = [
  {
    day: "Monday",
    date: "May 5",
    isToday: false,
    items: [
      { id: 1, customer: "Michael Thompson", address: "1842 Oak Valley Dr", time: "8:00 AM", service: "Full Clean", completed: true },
      { id: 2, customer: "Sarah Chen", address: "567 Maple Lane", time: "10:30 AM", service: "Chemical Balance", completed: true },
      { id: 3, customer: "Robert Martinez", address: "2901 Pine Street", time: "1:00 PM", service: "Filter Clean", completed: true },
    ],
  },
  {
    day: "Tuesday",
    date: "May 6",
    isToday: false,
    items: [
      { id: 4, customer: "Emily Davis", address: "445 Birch Avenue", time: "9:00 AM", service: "Full Clean", completed: true },
      { id: 5, customer: "Lisa Anderson", address: "789 Elm Court", time: "11:30 AM", service: "Equipment Check", completed: true },
    ],
  },
  {
    day: "Wednesday",
    date: "May 7",
    isToday: true,
    items: [
      { id: 6, customer: "James Wilson", address: "1123 Cedar Blvd", time: "8:30 AM", service: "Full Clean", completed: true },
      { id: 7, customer: "Michael Thompson", address: "1842 Oak Valley Dr", time: "11:00 AM", service: "Chemical Balance", completed: false },
      { id: 8, customer: "Sarah Chen", address: "567 Maple Lane", time: "2:00 PM", service: "Vacuum & Skim", completed: false },
    ],
  },
  {
    day: "Thursday",
    date: "May 8",
    isToday: false,
    items: [
      { id: 9, customer: "Robert Martinez", address: "2901 Pine Street", time: "9:00 AM", service: "Full Clean", completed: false },
      { id: 10, customer: "Emily Davis", address: "445 Birch Avenue", time: "12:00 PM", service: "Chemical Balance", completed: false },
      { id: 11, customer: "Lisa Anderson", address: "789 Elm Court", time: "3:00 PM", service: "Filter Clean", completed: false },
    ],
  },
  {
    day: "Friday",
    date: "May 9",
    isToday: false,
    items: [
      { id: 12, customer: "James Wilson", address: "1123 Cedar Blvd", time: "8:00 AM", service: "Equipment Check", completed: false },
      { id: 13, customer: "Michael Thompson", address: "1842 Oak Valley Dr", time: "10:30 AM", service: "Full Clean", completed: false },
    ],
  },
]

export function WeeklySchedule() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Weekly Schedule</h2>
          <p className="text-sm text-muted-foreground">
            May 5 - May 9, 2026
          </p>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-primary" />
            <span className="text-muted-foreground">Completed</span>
          </div>
          <div className="flex items-center gap-2">
            <Circle className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">Pending</span>
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        {weekSchedule.map((day) => (
          <div
            key={day.day}
            className={cn(
              "rounded-lg border bg-card",
              day.isToday ? "border-primary" : "border-border"
            )}
          >
            <div
              className={cn(
                "rounded-t-lg border-b px-4 py-3",
                day.isToday
                  ? "border-primary/30 bg-primary/10"
                  : "border-border bg-secondary/30"
              )}
            >
              <p
                className={cn(
                  "text-sm font-semibold",
                  day.isToday ? "text-primary" : "text-foreground"
                )}
              >
                {day.day}
              </p>
              <p className="text-xs text-muted-foreground">{day.date}</p>
            </div>
            <div className="space-y-2 p-3">
              {day.items.length > 0 ? (
                day.items.map((item) => (
                  <div
                    key={item.id}
                    className={cn(
                      "rounded-md border p-3 transition-colors",
                      item.completed
                        ? "border-border/50 bg-secondary/20"
                        : "border-border bg-card hover:bg-secondary/30"
                    )}
                  >
                    <div className="mb-2 flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        {item.time}
                      </div>
                      {item.completed ? (
                        <CheckCircle2 className="h-4 w-4 text-primary" />
                      ) : (
                        <Circle className="h-4 w-4 text-muted-foreground" />
                      )}
                    </div>
                    <div className="mb-1.5 flex items-center gap-1.5">
                      <User className="h-3 w-3 text-muted-foreground" />
                      <p
                        className={cn(
                          "text-sm font-medium",
                          item.completed ? "text-muted-foreground" : "text-foreground"
                        )}
                      >
                        {item.customer}
                      </p>
                    </div>
                    <div className="mb-2 flex items-start gap-1.5">
                      <MapPin className="mt-0.5 h-3 w-3 shrink-0 text-muted-foreground" />
                      <p className="text-xs text-muted-foreground">{item.address}</p>
                    </div>
                    <span
                      className={cn(
                        "inline-block rounded-full px-2 py-0.5 text-xs font-medium",
                        item.completed
                          ? "bg-secondary/50 text-muted-foreground"
                          : "bg-primary/10 text-primary"
                      )}
                    >
                      {item.service}
                    </span>
                  </div>
                ))
              ) : (
                <p className="py-4 text-center text-sm text-muted-foreground">
                  No appointments
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
