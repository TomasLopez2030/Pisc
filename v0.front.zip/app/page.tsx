"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { CustomerList } from "@/components/customer-list"
import { WeeklySchedule } from "@/components/weekly-schedule"
import { DashboardOverview } from "@/components/dashboard-overview"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("dashboard")

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="flex-1 overflow-auto">
        <div className="px-8 py-6">
          {activeTab === "dashboard" && <DashboardOverview />}
          {activeTab === "customers" && <CustomerList />}
          {activeTab === "schedule" && <WeeklySchedule />}
          {activeTab === "routes" && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">Routes</h2>
              <p className="text-muted-foreground">Route optimization coming soon.</p>
            </div>
          )}
          {activeTab === "invoices" && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">Invoices</h2>
              <p className="text-muted-foreground">Invoice management coming soon.</p>
            </div>
          )}
          {activeTab === "settings" && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">Settings</h2>
              <p className="text-muted-foreground">Account settings coming soon.</p>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
